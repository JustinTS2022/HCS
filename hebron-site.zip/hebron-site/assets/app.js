// Hebron Championship Series - shared site logic
// Reads live data straight from the Google Sheet via the gviz CSV endpoint.
// No API key, no backend - the Sheet just needs to be shared as
// "Anyone with the link can view".

const SHEET_ID = "1W1zuo1JuSsp9CL56Pn7g6zNS_dhOnJWBU2ZVBW6_t9U";

function gvizUrl(sheetName) {
  return `https://docs.google.com/spreadsheets/d/${SHEET_ID}/gviz/tq?tqx=out:csv&sheet=${encodeURIComponent(sheetName)}`;
}

// Minimal quote-aware CSV parser. Google's CSV export always quotes fields,
// so this only needs to handle "" as an escaped quote inside a quoted field.
function parseCSV(text) {
  const rows = [];
  let row = [];
  let field = "";
  let inQuotes = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (inQuotes) {
      if (c === '"') {
        if (text[i + 1] === '"') {
          field += '"';
          i++;
        } else {
          inQuotes = false;
        }
      } else {
        field += c;
      }
    } else {
      if (c === '"') {
        inQuotes = true;
      } else if (c === ",") {
        row.push(field);
        field = "";
      } else if (c === "\n" || c === "\r") {
        if (c === "\r" && text[i + 1] === "\n") i++;
        row.push(field);
        rows.push(row);
        row = [];
        field = "";
      } else {
        field += c;
      }
    }
  }
  if (field.length > 0 || row.length > 0) {
    row.push(field);
    rows.push(row);
  }
  return rows.filter((r) => r.some((c) => c !== ""));
}

async function fetchSheet(sheetName) {
  const res = await fetch(gvizUrl(sheetName), { cache: "no-store" });
  if (!res.ok) {
    throw new Error(`Could not load "${sheetName}" (HTTP ${res.status}). Is the Sheet still set to "Anyone with the link can view"?`);
  }
  const text = await res.text();
  return parseCSV(text);
}

// The first cell of row 1 in several tabs has the sheet's title text glued
// onto the real first header (Google merges a title cell and the export
// jams the merged text + the next real header into one string). This pulls
// the last "word cluster" off that mess by matching against a known header.
function stripTitlePrefix(cellText, knownHeader) {
  const idx = cellText.lastIndexOf(knownHeader);
  if (idx === -1) return cellText.trim();
  return cellText.slice(idx).trim();
}

function el(tag, attrs = {}, children = []) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === "class") node.className = v;
    else if (k === "text") node.textContent = v;
    else node.setAttribute(k, v);
  }
  for (const child of [].concat(children)) {
    if (child == null) continue;
    node.appendChild(typeof child === "string" ? document.createTextNode(child) : child);
  }
  return node;
}

function renderTable(container, headers, rows, opts = {}) {
  container.innerHTML = "";
  const table = el("table", { class: "data-table" });
  const thead = el("thead", {}, el("tr", {}, headers.map((h) => el("th", { text: h }))));
  const tbody = el("tbody", {}, rows.map((r) => {
    const tr = el("tr", {});
    r.forEach((cell, i) => {
      const td = el("td", { text: cell });
      if (opts.cellClass) {
        const cls = opts.cellClass(cell, i, r);
        if (cls) td.className = cls;
      }
      tr.appendChild(td);
    });
    return tr;
  }));
  table.appendChild(thead);
  table.appendChild(tbody);
  container.appendChild(table);
}

function showError(container, err) {
  container.innerHTML = "";
  container.appendChild(
    el("div", { class: "error-box" }, [
      el("strong", { text: "Couldn't load live data." }),
      el("div", { text: err.message || String(err) }),
    ])
  );
  console.error(err);
}

function buildNav(active) {
  const links = [
    ["index.html", "Standings"],
    ["player-ratings.html", "Player Ratings"],
    ["draft-board.html", "Draft Board"],
    ["game-log.html", "Game Log"],
  ];
  const nav = document.querySelector("[data-nav]");
  if (!nav) return;
  nav.innerHTML = "";
  nav.appendChild(el("div", { class: "brand", text: "Hebron Championship Series" }));
  const linkWrap = el("div", { class: "nav-links" });
  for (const [href, label] of links) {
    linkWrap.appendChild(el("a", { href, class: href === active ? "active" : "", text: label }));
  }
  nav.appendChild(linkWrap);
}
